#include "admin_panel.h"
#include "ui_admin_panel.h"
#include "mainwindow.h"

Admin_panel::Admin_panel(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Admin_panel)
{
    ui->setupUi(this);
}

Admin_panel::~Admin_panel()
{
    delete ui;
}

void Admin_panel::on_Admin_to_main_window_clicked()
{
    MainWindow *main_window = new MainWindow();
    main_window->show();
    this->close();
}

