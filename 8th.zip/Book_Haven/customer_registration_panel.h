#ifndef CUSTOMER_REGISTRATION_PANEL_H
#define CUSTOMER_REGISTRATION_PANEL_H

#include <QDialog>
#include "databaseHeader.h"
namespace Ui {
class customer_registration_panel;
}

class customer_registration_panel : public QDialog
{
    Q_OBJECT

public:
    explicit customer_registration_panel(QWidget *parent = nullptr);
    ~customer_registration_panel();

private slots:
    void on_customer_reg_to_view_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_9_clicked();

private:
    Ui::customer_registration_panel *ui;
};

#endif // CUSTOMER_REGISTRATION_PANEL_H
