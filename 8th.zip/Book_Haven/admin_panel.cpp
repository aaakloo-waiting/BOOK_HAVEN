#include "admin_panel.h"
#include "ui_admin_panel.h"
#include "mainwindow.h"

Admin_panel::Admin_panel(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Admin_panel)
{
    ui->setupUi(this);
}

Admin_panel::~Admin_panel()
{
    delete ui;
}

void Admin_panel::on_Admin_to_main_window_clicked()
{
    MainWindow *main_window = new MainWindow();
    main_window->show();
    this->close();
}

// void Admin::addBook(int ID, const QString& name, const QString& author, int quantity, AccessLevel accessLevel) {
//     Book book;
//     book.ID = ID;
//     book.name = name;
//     book.author = author;
//     book.quantity = quantity;
//     book.accessLevel = accessLevel;
//     books.push_back(book);
// }

// void Admin::grantPermission(const Book& book, AccessLevel accessLevel) {
//     // Find the book in the collection and update its access level
//     for (auto& b : books) {
//         if (b.ID == book.ID) {
//             b.accessLevel = accessLevel;
//             break;
//         }
//     }
// }
