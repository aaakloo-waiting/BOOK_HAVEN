#ifndef ADMIN_PANEL_H
#define ADMIN_PANEL_H
// Admin.h
#include "Books.h"
#include <vector>
#include "AccessLevel.h"
#include <QDialog>
namespace Ui {
class Admin_panel;
}
// class Admin {
// public:
//     void addBook(int ID, const QString& name, const QString& author, int quantity, AccessLevel accessLevel);
//     void grantPermission(const Book& book, AccessLevel accessLevel);

// private:
//     std::vector<Book> books;
// };
class Admin_panel : public QDialog
{
    Q_OBJECT

public:
    void addBook(int ID, const QString& name, const QString& author, int quantity, AccessLevel accessLevel);
    void grantPermission(const Book& book, AccessLevel accessLevel);
    explicit Admin_panel(QWidget *parent = nullptr);
    ~Admin_panel();

private slots:
    void on_Admin_to_main_window_clicked();

private:
    std::vector<Book> books;
    Ui::Admin_panel *ui;
};

#endif // ADMIN_PANEL_H






