#include "customer_registration_panel.h"
#include "ui_customer_registration_panel.h"
#include "mainwindow.h"
#include <QMessageBox>
customer_registration_panel::customer_registration_panel(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::customer_registration_panel)
{
    ui->setupUi(this);
}

customer_registration_panel::~customer_registration_panel()
{
    delete ui;
}

void customer_registration_panel::on_customer_reg_to_view_clicked()
{
    MainWindow *ptr_main_win= new MainWindow();
    ptr_main_win->go_to_view();
    this->close();
}

// Register button
void customer_registration_panel::on_pushButton_10_clicked()
{
    QString tFull_Name = ui->txtFull_Name->text();
    QString tEmail_Address = ui->txtEmail_Address->text();
    QString tContact_Number = ui->txtContact_Number->text();
    QString tBilling_Address = ui->txtBilling_Address->toPlainText();
    QString tPassword = ui->txtPassword->text();
    QString tFavorite_Genre_of_Books = ui->txtFavorite_Genre_of_Books->text();
    QString tMembership_Type = ui->txtMembership_Type->text();
    QString tPreferred_Payment_Method = ui->txtPreferred_Payment_Method->text();

    qDebug()<<"customerName: "<<tFull_Name;
    QMessageBox::information(this, tr("Welcome_Text"), tr("Congratulations! You're a part of BookHaven now!"));

    MainWindow * ptr_main_win= new MainWindow;
    ptr_main_win->go_to_customer_login();
    this->close();

    QSqlDatabase database = QSqlDatabase :: addDatabase("QSQLITE");
    database.setDatabaseName("D:/BOOK_HAVEN/Database_sqlite/Book_Haven_customer_manager.db");

    if(QFile::exists("D:/BOOK_HAVEN/Database_sqlite/Book_Haven_customer_manager.db"))
        qDebug() << "Database file exists";
    else
        qDebug() << "Database file does not exist";

    if(!database.open())
        qDebug() << "Error: Unable to open database";
    else
        qDebug() << "Database opened successfully";

    QSqlQuery query;
    query = QSqlQuery(database);

    query.prepare("insert into Customer_Reg(Full_Name, Email_Address, Contact_Number, Billing_Address, Password, Favorite_Genre_of_Books, Membership_Type, Preferred_Payment_Method) values ('" + tFull_Name + "','" + tEmail_Address + "','" + tContact_Number + "','" + tBilling_Address + "','" + tPassword + "','" + tFavorite_Genre_of_Books + "','" + tMembership_Type + "','" + tPreferred_Payment_Method + "');");
    query.exec();
    database.close();

}


void customer_registration_panel::on_pushButton_9_clicked()
{
    ui->txtFull_Name->clear();
    ui->txtEmail_Address->clear();
    ui->txtContact_Number->clear();
    ui->txtBilling_Address->clear();
    ui->txtPassword->clear();
    ui->txtFavorite_Genre_of_Books->clear();
    ui->txtMembership_Type->clear();
    ui->txtPreferred_Payment_Method->clear();
}

