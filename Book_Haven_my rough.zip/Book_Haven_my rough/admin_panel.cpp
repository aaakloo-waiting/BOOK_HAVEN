#include "admin_panel.h"
#include "ui_admin_panel.h"
#include "mainwindow.h"
#include "adminsignup.h"
#include "bookhavenmanager.h"
Admin_panel::Admin_panel(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Admin_panel)
{
    ui->setupUi(this);
}

Admin_panel::~Admin_panel()
{
    delete ui;
}

void Admin_panel::on_signUpButton_clicked()
{
    this->hide();
    AdminSignUp adminsignup;
    adminsignup.exec();
}

void Admin_panel::on_loginButton_clicked()
{
    QString username = ui->ausername->text();
    QString password = ui->apassword->text();

    QSqlDatabase database = QSqlDatabase :: addDatabase("QSQLITE");
    database.setDatabaseName("D:/BOOK_HAVEN/Database_sqlite/Book_Haven_customer_manager.db");

    if(QFile::exists("D:/BOOK_HAVEN/Database_sqlite/Book_Haven_customer_manager.db"))
        qDebug() << "Database file exists";
    else
        qDebug() << "Database file does not exist";

    if(!database.open())
        qDebug() << "Error: Unable to open database";
    else
        qDebug() << "Database opened successfully";

    QSqlQuery query;
    query = QSqlQuery(database);

    BookHavenManager lib;

    if(!username.isEmpty() & !password.isEmpty())
    {
        //Create the body of the query
        QString checkLogin = {"SELECT * FROM Admin_Reg WHERE AdminName='"
                              +username+"' AND Password='"+password+"'"};

        if(query.exec(checkLogin))
        {
            int count = 0;
            while(query.next())
            {
                count++;
            }
            if(count == 1)
            {
                this->hide();
                lib.exec();
            }
            else if(count < 1){
                QMessageBox::warning(this, "Empty", "You are not registered!");
                ui->ausername->clear();
                ui->apassword->clear();
            }
        }
        else
            qDebug() << "cannot select from accounts";
    }
    else
        QMessageBox::warning(this, "Empty", "Fields are empty!");    query.exec();
    database.close();
}


void Admin_panel::on_admin_panel_to_mainwindow_clicked()
{
    MainWindow *main_window = new MainWindow();
    main_window->show();
    this->close();
}

