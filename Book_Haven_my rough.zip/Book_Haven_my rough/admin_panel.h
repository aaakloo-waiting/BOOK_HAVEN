#ifndef ADMIN_PANEL_H
#define ADMIN_PANEL_H
#include <QDialog>
#include "databaseHeader.h"
namespace Ui {
class Admin_panel;
}
// class Admin {
// public:
//     void addBook(int ID, const QString& name, const QString& author, int quantity, AccessLevel accessLevel);
//     void grantPermission(const Book& book, AccessLevel accessLevel);

// private:
//     std::vector<Book> books;
// };
class Admin_panel : public QDialog
{
    Q_OBJECT

public:
    explicit Admin_panel(QWidget *parent = nullptr);
    ~Admin_panel();

private slots:
    void on_signUpButton_clicked();

    void on_loginButton_clicked();

    void on_admin_panel_to_mainwindow_clicked();

private:
    Ui::Admin_panel *ui;
};

#endif // ADMIN_PANEL_H






