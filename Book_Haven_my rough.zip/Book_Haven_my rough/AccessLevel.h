#ifndef ACCESSLEVEL_H
#define ACCESSLEVEL_H
// AccessLevel.h
enum class AccessLevel {
    CUSTOMER,
    VIEWER,
    ADMIN,
};

#endif // ACCESSLEVEL_H
