// #ifndef MANAGEGENRE_H
// #define MANAGEGENRE_H

// #include "databaseHeader.h"

// namespace Ui {
// class managegenre;
// }

// class managegenre : public QDialog
// {
//     Q_OBJECT

// public:
//     explicit managegenre(QWidget *parent = nullptr);
//     ~managegenre();

// private slots:
//     void on_add_clicked();

// private:
//     Ui::managegenre *ui;
//     QSqlQueryModel *model;
// };

// #endif // MANAGEGENRE_H
