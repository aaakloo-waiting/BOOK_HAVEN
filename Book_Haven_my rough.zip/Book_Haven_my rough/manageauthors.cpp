#include "manageauthors.h"
#include "ui_manageauthors.h"

manageauthors::manageauthors(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::manageauthors)
{
    ui->setupUi(this);
}

manageauthors::~manageauthors()
{
    delete ui;
}
