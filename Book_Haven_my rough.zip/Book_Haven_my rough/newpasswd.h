#ifndef NEWPASSWD_H
#define NEWPASSWD_H

#include <QDialog>

namespace Ui {
class newpasswd;
}

class newpasswd : public QDialog
{
    Q_OBJECT

public:
    explicit newpasswd(QWidget *parent = nullptr);
    ~newpasswd();

private:
    Ui::newpasswd *ui;
};

#endif // NEWPASSWD_H
