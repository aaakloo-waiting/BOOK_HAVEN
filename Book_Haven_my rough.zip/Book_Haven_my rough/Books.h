#ifndef BOOKS_H
#define BOOKS_H
// Book.h
#include <QString>
#include "AccessLevel.h"

class Book {
public:
    int ID;
    QString name;
    QString author;
    int quantity;
    AccessLevel accessLevel;  // Use the AccessLevel enum
};

#endif // BOOKS_H
