#ifndef MANAGEAUTHORS_H
#define MANAGEAUTHORS_H

#include <QDialog>

namespace Ui {
class manageauthors;
}

class manageauthors : public QDialog
{
    Q_OBJECT

public:
    explicit manageauthors(QWidget *parent = nullptr);
    ~manageauthors();

private:
    Ui::manageauthors *ui;
};

#endif // MANAGEAUTHORS_H
