#include "adminsignup.h"
#include "ui_adminsignup.h"
#include "admin_panel.h"
#include "bookhavenmanager.h"
AdminSignUp::AdminSignUp(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AdminSignUp)
{
    ui->setupUi(this);
}

AdminSignUp::~AdminSignUp()
{
    delete ui;
}

void AdminSignUp::on_createButton_clicked()
{
    QString tAdminName = ui->AdminName->text();
    QString tName = ui->Name->text();
    QString tPassword = ui->Password->text();

    BookHavenManager lib;
    QSqlDatabase database = QSqlDatabase :: addDatabase("QSQLITE");
    database.setDatabaseName("D:/BOOK_HAVEN/Database_sqlite/Book_Haven_customer_manager.db");

    if(QFile::exists("D:/BOOK_HAVEN/Database_sqlite/Book_Haven_customer_manager.db"))
        qDebug() << "Database file exists";
    else
        qDebug() << "Database file does not exist";

    if(!database.open())
        qDebug() << "Error: Unable to open database";
    else
        qDebug() << "Database opened successfully";

    if((!tAdminName.isEmpty() & !tName.isEmpty()) & !tPassword.isEmpty())
    {
        QString searchAcc = {"SELECT * FROM Admin_Reg WHERE AdminName='"
                             +tAdminName+"' AND Name='"+tName+"' AND password='"
                             +tPassword+"'"};
        auto search = QSqlQuery(database);
        if(!search.exec(searchAcc))
            qDebug() << "Cannot select";
        int count = 0;
        while(search.next())
        {
            count++;
        }

        if(count>=1){
            QMessageBox::warning(this, "Failed", "Account Already Exist with same information!");
            ui->AdminName->clear();
            ui->Name->clear();
            ui->Password->clear();
        }
        else
        {
            QSqlQuery query;
            query = QSqlQuery(database);
            query.prepare("insert into Admin_Reg(AdminName, Name, Password) values ('" + tAdminName + "','" + tName + "','" + tPassword + "');");
            QMessageBox::information(this, tr("Welcome_Text"), tr("Admin Connect Successful! "));
            this->hide();
            Admin_panel adminpanel;
            adminpanel.exec();
        }
    }
    else
        QMessageBox::warning(this, "Empty", "Fields are empty!");
}


void AdminSignUp::on_resetBtn_clicked()
{
    ui->AdminName->clear();
    ui->Name->clear();
    ui->Password->clear();
}


void AdminSignUp::on_backButton_clicked()
{
    this->hide();
    Admin_panel adminpanel;
    adminpanel.exec();
}

