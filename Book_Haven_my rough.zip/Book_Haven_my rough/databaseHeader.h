#ifndef DATABASEHEADER_H
#define DATABASEHEADER_H

#include <QSqlDatabase>
#include<QSqlDriver>
#include<QSqlError>
#include<QDebug>
#include<QSqlTableModel>
#include <QFile>
#include <QSqlQuery>
#include<QMessageBox>
#include<QDialog>
#include<QSqlQueryModel>
#include <QtSql/QSqlDatabase>
#include <QDir>
#endif // DATABASEHEADER_H
