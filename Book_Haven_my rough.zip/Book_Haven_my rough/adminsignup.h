#ifndef ADMINSIGNUP_H
#define ADMINSIGNUP_H
#include "databaseHeader.h"
namespace Ui {
class AdminSignUp;
}

class AdminSignUp : public QDialog
{
    Q_OBJECT

public:
    explicit AdminSignUp(QWidget *parent = nullptr);
    ~AdminSignUp();

private slots:
    void on_createButton_clicked();

    void on_resetBtn_clicked();

    void on_backButton_clicked();

private:
    Ui::AdminSignUp *ui;
};

#endif // ADMINSIGNUP_H
