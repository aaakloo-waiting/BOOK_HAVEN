#ifndef BOOKHAVENMANAGER_H
#define BOOKHAVENMANAGER_H

#include "databaseHeader.h"

namespace Ui {
class BookHavenManager;
}

class BookHavenManager : public QDialog
{
    Q_OBJECT

public:
    explicit BookHavenManager(QWidget *parent = nullptr);
    ~BookHavenManager();

    QSqlDatabase db;
    void connectDB();

    void setUsername(QString username);
    void showBookNum();
    void showMemberNum();
    void showAuthorNum();
    void showCover();

private slots:
    void on_logout_to_admin_panel_clicked();

    void on_manageGenre_2_clicked();

private:
    Ui::BookHavenManager *ui;
    QString filename = QDir::homePath()+ "/libraryDB.sqlite";
    QString username;
};

#endif // BOOKHAVENMANAGER_H
