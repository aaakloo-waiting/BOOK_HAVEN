#include "bookhavenmanager.h"
#include "ui_bookhavenmanager.h"
#include "admin_panel.h"
#include "manageauthors.h"
#include "managegenre.h"
BookHavenManager::BookHavenManager(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::BookHavenManager)
{
    // ui->setupUi(this);
    // connectDB();
    // setUsername(username);
    // showBookNum();
    // showMemberNum();
    // showAuthorNum();
    // showCover();
}

BookHavenManager::~BookHavenManager()
{
    delete ui;
}

void BookHavenManager::on_logout_to_admin_panel_clicked()
{
    Admin_panel admin_panel;
    this->hide();
    admin_panel.exec();
}


void BookHavenManager::on_manageGenre_2_clicked()
{
    this->hide();
    // managegenre manageG;
    // manageG.exec();
}

// void BookHavenManager::connectDB(){
//     db = QSqlDatabase::addDatabase("QSQLITE", "SQLITE");

//     //Set the database path
//     db.setDatabaseName(this->filename);

//     //check if the database is opened
//     if(!db.open())
//         QMessageBox::critical(this, "FAILED", "DB is not opened");

//     //définir la requete sur la base de données
//     auto query = QSqlQuery(db);

//     //Create a table named accounts
//     QString accountTable{"CREATE TABLE IF NOT EXISTS accounts"
//                          "(username VARCHAR(20), name VARCHAR(20),"
//                          "password VARCHAR(20))"};

//     if(!query.exec(accountTable))
//         QMessageBox::critical(this,"Info","Cannot create accounts");

//     //Create a table named genres
//     QString genreTable{"CREATE TABLE IF NOT EXISTS genres"
//                        "(ID INTEGER, name VARCHAR(20))"};
//     if(!query.exec(genreTable))
//         QMessageBox::critical(this,"Info","Cannot create genre Table");

//     //Create a table named authors
//     QString authorTable{"CREATE TABLE IF NOT EXISTS authors"
//                         "(ID INTEGER, firstName VARCHAR(20), lastName VARCHAR(20),"
//                         "expertise VARCHAR(20), about VARCHAR(40))"};
//     if(!query.exec(authorTable))
//         QMessageBox::critical(this,"Info","Cannot create authors Table");

//     //Create a table named members
//     QString memberTable{"CREATE TABLE IF NOT EXISTS members"
//                         "(ID INTEGER PRIMARY KEY, firstName VARCHAR(20), lastName VARCHAR(20),"
//                         "phone VARCHAR(20), email VARCHAR(40), gender VARCHAR(10))"};
//     if(!query.exec(memberTable))
//         QMessageBox::critical(this,"Info","Cannot create members Table");

//     //Create a table named books
//     QString bookTable{"CREATE TABLE IF NOT EXISTS books"
//                       "(ID INTEGER PRIMARY KEY, ISBN VARCHAR(20), name VARCHAR(20),"
//                       "author VARCHAR(20), genre VARCHAR(20), quantity INT,"
//                       "publisher VARCHAR(20), price REAL, date VARCHAR(10),"
//                       "description VARCHAR(80), cover VARCHAR(50))"};
//     if(!query.exec(bookTable))
//         QMessageBox::critical(this,"Failed","Cannot create books Table");

//     //Create a table named bookStatus
//     QString Table{"CREATE TABLE IF NOT EXISTS bookStatus"
//                   "(Book INTEGER, Member INTEGER, Status VARCHAR(10),"
//                   "IssueDate date, ReturnDate date, Note VARCHAR(50))"};
//     if(!query.exec(Table))
//         QMessageBox::critical(this,"Info","Cannot create bookStatus Table");
// }
