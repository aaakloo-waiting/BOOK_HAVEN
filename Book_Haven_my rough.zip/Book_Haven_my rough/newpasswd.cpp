#include "newpasswd.h"
#include "ui_newpasswd.h"

newpasswd::newpasswd(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::newpasswd)
{
    ui->setupUi(this);
}

newpasswd::~newpasswd()
{
    delete ui;
}
