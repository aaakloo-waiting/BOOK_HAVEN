#include "customer_registration_panel.h"
#include "ui_customer_registration_panel.h"
#include "mainwindow.h"
customer_registration_panel::customer_registration_panel(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::customer_registration_panel)
{
    ui->setupUi(this);
}

customer_registration_panel::~customer_registration_panel()
{
    delete ui;
}

void customer_registration_panel::on_customer_reg_to_view_clicked()
{
    MainWindow *ptr_main_win= new MainWindow();
    ptr_main_win->go_to_view();
    this->close();
}


void customer_registration_panel::on_customer_reg_db_clicked()
{
    QString customer_name = ui->lineEdit_2->text();
    QString mail  = ui->lineEdit_9->text();
    QString contact = ui->lineEdit_10->text();
    QString address = ui->textEdit_2->toPlainText();
    QString password = ui->lineEdit_12->text();

    qDebug() << "Customer name: "<< customer_name << " Password: " << password << " added to database";

    QSqlDatabase database = QSqlDatabase :: addDatabase("QSQLITE");
    database.setDatabaseName("D:/BOOK_HAVEN/Database_sqlite/Book_Haven_customer_manager.db");

    if(QFile :: exists("D:/BOOK_HAVEN/Database_sqlite/Book_Haven_customer_manager.db"))
        qDebug() << "Database file exists";
    else
        qDebug() << "Database file does not exist";

    if(!database.open())
        qDebug() << "Error: Unable to open database";
    else
        qDebug() << "Database opened successfully";

    QSqlQuery query;
    query = QSqlQuery(database);

    query.prepare("insert into customer(name,email,contact,address,password) values ('" + customer_name + "','" + mail + "','" + contact + "','" + address + "','" + password + ");");
    query.exec();
    database.close();

    ui->lineEdit_2->clear();
    ui->lineEdit_9->clear();
    ui->lineEdit_10->clear();
    ui->textEdit_2->clear();
    ui->lineEdit_12->clear();
}

