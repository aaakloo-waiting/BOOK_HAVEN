#include "admin_panel.h"
#include "ui_admin_panel.h"

Admin_panel::Admin_panel(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Admin_panel)
{
    ui->setupUi(this);
}

Admin_panel::~Admin_panel()
{
    delete ui;
}
