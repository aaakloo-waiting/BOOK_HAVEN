#ifndef ADMIN_PANEL_H
#define ADMIN_PANEL_H

#include <QDialog>

namespace Ui {
class Admin_panel;
}

class Admin_panel : public QDialog
{
    Q_OBJECT

public:
    explicit Admin_panel(QWidget *parent = nullptr);
    ~Admin_panel();

private:
    Ui::Admin_panel *ui;
};

#endif // ADMIN_PANEL_H
